#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/user/NOXbot/NOXbot')

import asyncio
from bot.database.session import get_session_factory
from sqlalchemy import text, inspect

async def run_migration():
    session_factory = get_session_factory()
    async with session_factory() as session:
        try:
            # Check if columns exist
            conn = await session.connection()
            def check_columns(connection):
                inspector = inspect(connection)
                columns = [col['name'] for col in inspector.get_columns('users')]
                return columns
            
            columns = await conn.run_sync(check_columns)
            
            # Add columns if they don't exist
            if 'email' not in columns:
                await session.execute(text("ALTER TABLE users ADD COLUMN email VARCHAR(255)"))
                print("  ✅ Added email column")
            
            if 'password' not in columns:
                await session.execute(text("ALTER TABLE users ADD COLUMN password VARCHAR(255)"))
                print("  ✅ Added password column")
            
            if 'customer_name' not in columns:
                await session.execute(text("ALTER TABLE users ADD COLUMN customer_name VARCHAR(255)"))
                print("  ✅ Added customer_name column")
            
            await session.commit()
            print("✅ Migration completed successfully")
        except Exception as e:
            await session.rollback()
            print(f"❌ Migration failed: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(run_migration())
