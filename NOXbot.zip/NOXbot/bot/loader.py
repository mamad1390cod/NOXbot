"""Loader module — creates and exposes the shared Bot, Dispatcher and BotServiceContainer.

Handlers import these singletons to access the bot, dispatcher, and services.
"""

import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from bot.config import get_settings

logger = logging.getLogger(__name__)

settings = get_settings()

# Telegram API limits
_bot = Bot(
    token=settings.bot_token,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML),
)

_dp = Dispatcher(storage=MemoryStorage())


def get_bot() -> Bot:
    """Return the shared Bot instance."""
    return _bot


def get_dispatcher() -> Dispatcher:
    """Return the shared Dispatcher instance."""
    return _dp


def register_middlewares() -> None:
    """Register global middlewares on the dispatcher.

    Order matters: UserContextMiddleware runs first and injects ``user``/``uow``,
    then RbacMiddleware uses those to inject ``permissions``, then throttling.
    """
    from bot.middlewares import (
        ThrottlingMiddleware,
        UserContextMiddleware,
        RbacMiddleware,
        MaintenanceMiddleware,
        AbuseMiddleware,
    )

    for observer in (_dp.message, _dp.callback_query, _dp.my_chat_member):
        observer.middleware(UserContextMiddleware())
    for observer in (_dp.message, _dp.callback_query, _dp.my_chat_member):
        observer.middleware(MaintenanceMiddleware())
    for observer in (_dp.message, _dp.callback_query, _dp.my_chat_member):
        observer.middleware(AbuseMiddleware())
    for observer in (_dp.message, _dp.callback_query, _dp.my_chat_member):
        observer.middleware(RbacMiddleware())
    for observer in (_dp.message, _dp.callback_query):
        observer.middleware(ThrottlingMiddleware())